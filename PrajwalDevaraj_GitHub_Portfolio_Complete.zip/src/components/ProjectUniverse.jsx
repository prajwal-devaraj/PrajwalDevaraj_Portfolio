import { useMemo, useState } from "react";
import { projects } from "../data/content";

const featuredNames = ["CivicLens AI", "CodeTheGenome", "AdFusion AI", "Agentic Search Assistant", "SmartSpend", "SocialSphere Analytics Platform", "Disaster Management & Early Warning System", "Secure Healthcare DBaaS — SecHealthDB"];

export default function ProjectUniverse() {
  const [query, setQuery] = useState("");
  const [showAll, setShowAll] = useState(false);
  const categories = ["All", "AI", "Data", "Backend", "Security", "Civic", "Full-Stack", "Creative"];
  const [cat, setCat] = useState("All");

  const featured = projects.filter(p => featuredNames.includes(p.title));
  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return projects.filter(p => {
      const hay = `${p.title} ${p.category} ${p.blurb} ${p.tech.join(" ")} ${p.meta}`.toLowerCase();
      const matchesQ = !q || hay.includes(q);
      const matchesCat = cat === "All" || hay.includes(cat.toLowerCase());
      return matchesQ && matchesCat;
    });
  }, [query, cat]);

  return (
    <>
      <div className="hero-project-grid">
        {featured.slice(0, 4).map((p, i) => (
          <article className={`hero-project hp-${i}`} key={p.title}>
            <div className="project-index">0{i + 1}</div>
            <div className="project-category">{p.category}</div>
            <h3>{p.title}</h3>
            <p>{p.blurb}</p>
            {p.meta && <strong className="project-meta">{p.meta}</strong>}
            <div className="project-tech">{p.tech.map(t => <span key={t}>{t}</span>)}</div>
            {p.url && <a href={p.url} target="_blank" rel="noreferrer">Open project ↗</a>}
          </article>
        ))}
      </div>

      <div className="archive-head">
        <div>
          <span className="eyebrow">FULL ARCHIVE</span>
          <h3>{projects.length}+ projects & experiments</h3>
        </div>
        <button className="outline-btn" onClick={() => setShowAll(v => !v)}>{showAll ? "Collapse archive" : "Open full archive"}</button>
      </div>

      {showAll && (
        <div className="archive-wrap">
          <div className="project-controls">
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search projects, stacks, ideas…" />
            <div className="filter-row">{categories.map(c => <button key={c} className={cat === c ? "active" : ""} onClick={() => setCat(c)}>{c}</button>)}</div>
          </div>
          <div className="project-grid">
            {filtered.map((p, i) => (
              <article className="project-card" key={`${p.title}-${i}`}>
                <div className="project-topline"><span>PROJECT {String(i + 1).padStart(2, "0")}</span><span>{p.category}</span></div>
                <h4>{p.title}</h4>
                <p>{p.blurb}</p>
                {p.meta && <strong>{p.meta}</strong>}
                <div className="project-tech small">{p.tech.map(t => <span key={t}>{t}</span>)}</div>
                {p.url ? <a href={p.url} target="_blank" rel="noreferrer">OPEN ↗</a> : <span className="muted-link">ARCHIVE ENTRY</span>}
              </article>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
