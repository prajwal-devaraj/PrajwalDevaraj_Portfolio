import { useEffect, useMemo, useRef, useState } from "react";
import AICompanion from "./AICompanion";
import ProjectUniverse from "./ProjectUniverse";
import { experience, identities, milestones, profile, research, skillGroups, testimonials } from "../data/content";

const sections = ["about", "profile", "human", "mindset", "journey", "research", "projects", "voices", "skills", "education", "contact"];

function SectionTitle({ index, kicker, title, text }) {
  return <div className="section-title reveal">
    <div className="eyebrow">{String(index).padStart(2, "0")} / {kicker}</div>
    <h2>{title}</h2>
    {text && <p>{text}</p>}
  </div>;
}

function useReveal() {
  useEffect(() => {
    const els = [...document.querySelectorAll(".reveal")];
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: .12 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);
}

export default function Portfolio() {
  useReveal();
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [storyOpen, setStoryOpen] = useState(false);
  const [storyStep, setStoryStep] = useState(0);
  const [skillGroup, setSkillGroup] = useState("Software");
  const [progress, setProgress] = useState(0);
  const introRef = useRef(null);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - innerHeight;
      setProgress(max > 0 ? scrollY / max : 0);
    };
    addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setActiveTestimonial(v => (v + 1) % testimonials.length), 7500);
    return () => clearInterval(t);
  }, []);

  const story = useMemo(() => [
    ["BANGALORE", "It started with curiosity — technology, systems, people and the urge to understand how things work."],
    ["LEARNING", "Computer Science gave the curiosity structure: algorithms, databases, operating systems, networks, software and machine learning."],
    ["RESPONSIBILITY", "Administration, service work and campus operations taught a different kind of engineering: staying calm, communicating clearly and owning outcomes."],
    ["RESEARCH", "Research changed the questions. Instead of only asking how to build, he began asking what is worth investigating and how to measure whether an idea actually works."],
    ["TEACHING", "Teaching Operating Systems and Databases forced knowledge to become clear enough to share."],
    ["BUILDING", "Projects became a playground for AI, data, backend systems, civic technology, safety, computer vision, full-stack products and strange ideas worth testing."],
    ["LEADERSHIP", "Teams, sponsorship conversations and project ownership added another layer: people, vision, execution and accountability."],
    ["NOW", "The pattern is still the same: learn, build, break, understand, build again."],
    ["TO BE CONTINUED", "There are still systems not built, questions not asked, people not met and ideas that have not happened yet."]
  ], []);

  function navigate(id) {
    setStoryOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function speakIntro() {
    const text = "Hi, I’m Prajwal. If you’ve reached this part of the site, you’ve probably already realized that I build a lot of things. I studied computer science because I liked technology, but somewhere along the way I became interested in much more than writing code. I started researching AI, teaching, leading projects, working with people and exploring ideas from completely different areas. This website is a snapshot of that journey. I’m still learning, still experimenting and still figuring out what kind of problems I want to spend the next several years solving. Thanks for exploring my world.";
    if ("speechSynthesis" in window) {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = .95;
      u.pitch = .9;
      speechSynthesis.speak(u);
    }
  }

  return <div className="site-shell">
    <div className="scroll-progress" style={{ transform: `scaleX(${progress})` }} />
    <div className="ambient-grid" />
    <div className="ambient-orb one" />
    <div className="ambient-orb two" />
    <div className="noise" />

    <header className="nav">
      <button className="brand" onClick={() => scrollTo({ top: 0, behavior: "smooth" })}>PD<span>.</span></button>
      <nav>
        <button onClick={() => navigate("about")}>Story</button>
        <button onClick={() => navigate("research")}>Research</button>
        <button onClick={() => navigate("projects")}>Builds</button>
        <button onClick={() => navigate("journey")}>Journey</button>
        <button onClick={() => navigate("voices")}>Voices</button>
      </nav>
      <a className="nav-contact" href={`mailto:${profile.email}`}>Say hello ↗</a>
    </header>

    <main>
      <section className="hero" ref={introRef}>
        <div className="hero-copy">
          <div className="eyebrow reveal">PRAJWAL.DEV / DIGITAL UNIVERSE / 2026</div>
          <h1 className="reveal"><span>PRAJWAL</span><span>DEVARAJ</span></h1>
          <div className="identity-marquee reveal"><div>BUILDER <i>→</i> RESEARCHER <i>→</i> ENGINEER <i>→</i> TEACHER <i>→</i> STORYTELLER</div></div>
          <p className="hero-lead reveal">I build intelligent systems, explore ambitious research ideas, lead teams, teach what I learn, and turn curiosity into things people can actually use.</p>
          <p className="hero-sub reveal">Computer Science gave me the tools. Curiosity keeps deciding what I do with them.</p>
          <div className="hero-actions reveal">
            <button className="primary-btn" onClick={() => navigate("about")}>Enter my story</button>
            <button className="outline-btn" onClick={() => navigate("projects")}>Explore the builds</button>
            <button className="ghost-btn" onClick={() => setStoryOpen(true)}>▶ Play my story</button>
          </div>
          <div className="hero-meta reveal"><span>Bangalore, India <b>→</b> United States</span><span>M.S. Computer Science · Kent State University</span><span>GPA {profile.gpa}</span></div>
        </div>

        <div className="identity-core-wrap reveal">
          <div className="identity-ring ring-a" />
          <div className="identity-ring ring-b" />
          <div className="identity-ring ring-c" />
          <div className="core-center">PD<small>EST. 2001</small></div>
          {["AI", "SOFTWARE", "RESEARCH", "DATA", "WRITING", "LEADERSHIP", "SYSTEMS", "IDEAS"].map((x, i) => <span key={x} className={`orbit-label o${i}`}>{x}</span>)}
        </div>
      </section>

      <section id="about" className="section about-section">
        <SectionTitle index={1} kicker="THE HUMAN" title="Before the code, there’s a person." />
        <div className="story-copy reveal">
          <p>I’m <strong>Prajwal Devaraj</strong>, a software engineer, AI/ML researcher, builder, teacher, writer and endlessly curious computer science person originally from Bangalore, India.</p>
          <p>I completed my <strong>M.S. in Computer Science at Kent State University with a 3.97/4.00 GPA</strong>, but a lot of my education happened outside a syllabus too — inside research labs, team projects, internships, campus jobs, classrooms, failed experiments, late-night debugging sessions, leadership responsibilities and ideas I simply wanted to see exist.</p>
          <p>I enjoy building software, but what really interests me is the process behind it: understanding a problem deeply, finding structure inside complexity, experimenting with possibilities and gradually turning an idea into something real.</p>
          <p>My work has moved across <strong>software engineering, artificial intelligence, machine learning, computer vision, backend systems, data engineering, databases, distributed systems, full-stack development, civic technology, healthcare AI, security, disaster technology and agentic systems</strong>.</p>
          <p>But technology is only one part of me. I’ve taught students, worked customer-facing jobs, helped operate a school, led project teams, spoken with potential sponsors while helping seek funding for a college fest, written stories and poetry, and played cricket and volleyball.</p>
          <p>I don’t want my career to become a collection of titles. I want it to become a collection of things I <strong>built, learned, improved, contributed to and left better than I found them.</strong></p>
        </div>
        <div className="manifesto reveal">Still learning. <span>Still building.</span> Still becoming.</div>
      </section>

      <section id="profile" className="section profile-section">
        <SectionTitle index={2} kicker="PROFILE" title="The coordinates." text="A compact map of the person behind the projects." />
        <div className="passport reveal">
          <div className="passport-left">
            <div className="passport-monogram">PD</div>
            <h3>Prajwal Devaraj</h3>
            <div className="passport-row"><span>Current base</span><b>{profile.location}</b></div>
            <div className="passport-row"><span>Roots</span><b>{profile.roots}</b></div>
            <div className="passport-row"><span>Education</span><b>{profile.degree}</b></div>
            <div className="passport-row"><span>GPA</span><b>{profile.gpa}</b></div>
            <div className="passport-row"><span>Languages</span><b>{profile.languages.join(" · ")}</b></div>
            <div className="passport-row"><span>Email</span><a href={`mailto:${profile.email}`}>{profile.email}</a></div>
          </div>
          <div className="passport-right">
            {profile.socials.map(s => <a href={s.url} target="_blank" rel="noreferrer" className="social-line" key={s.label}><span><small>{s.note}</small>{s.label}</span><strong>{s.value}</strong><i>↗</i></a>)}
            <button className="social-line discord" onClick={() => navigator.clipboard?.writeText("prajwaldevaraj")}><span><small>Chat</small>Discord</span><strong>prajwaldevaraj</strong><i>copy</i></button>
          </div>
        </div>
      </section>

      <section id="human" className="section human-section">
        <SectionTitle index={3} kicker="MORE THAN CODE" title="Different rooms. Same person." />
        <div className="identity-grid">{identities.map((x, i) => <article className="identity-card reveal" key={x.title}><span>0{i + 1}</span><h3>{x.title}</h3><p>{x.text}</p></article>)}</div>
      </section>

      <section id="mindset" className="section mindset-section">
        <div className="giant-words" aria-hidden="true"><span>VISION</span><span>OWNERSHIP</span><span>EXECUTION</span><span>CURIOSITY</span><span>PEOPLE</span><span>IMPACT</span></div>
        <SectionTitle index={4} kicker="BUILDER MINDSET" title="Think like an engineer. Own it like a founder." />
        <div className="mindset-copy reveal">
          <p>I’m drawn to zero-to-one work. The interesting part is rarely just implementing a ticket. It is understanding why something should exist, what problem it solves, how people will experience it, what could break, how it should scale and what a better version might become.</p>
          <p>That mindset has followed me through independent projects, research, team leadership, technical work and non-technical roles. I care about <strong>vision, execution, technical quality, communication, ownership and real-world usefulness.</strong></p>
          <p>I’m still early in my journey. But I want to build with the responsibility of someone who expects their decisions to matter.</p>
        </div>
      </section>

      <section id="journey" className="section journey-section">
        <SectionTitle index={5} kicker="THE JOURNEY" title="No straight line." text="Every environment taught me something different." />
        <div className="timeline">
          {experience.map((e, i) => <article className="timeline-item reveal" key={`${e.role}-${i}`}>
            <div className="timeline-num">{String(i + 1).padStart(2, "0")}</div>
            <div className="timeline-body"><div className="timeline-period">{e.period}</div><h3>{e.role}</h3><h4>{e.org}</h4><p>{e.text}</p><div className="tag-row">{e.tags.map(t => <span key={t}>{t}</span>)}</div></div>
          </article>)}
        </div>
      </section>

      <section id="research" className="section research-section">
        <SectionTitle index={6} kicker="RESEARCH LAB" title="Questions I couldn’t leave alone." />
        <div className="research-grid">{research.map((r, i) => <article className={`research-card ${r.type} reveal`} key={r.title}><div className="research-top"><span>R-{String(i+1).padStart(2,"0")}</span><strong>{r.status}</strong></div><h3>{r.title}</h3><p>{r.text}</p><div className="research-pulse" /></article>)}</div>
      </section>

      <section id="projects" className="section project-section">
        <SectionTitle index={7} kicker="BUILDS" title="Things I made because I wanted to know if I could." text="A mix of serious systems, research prototypes, product experiments and curiosity-driven builds." />
        <ProjectUniverse />
      </section>

      <section id="voices" className="section voices-section">
        <SectionTitle index={8} kicker="VOICES" title="Don’t take my word for it." text="Recommendation excerpts from people who taught, mentored or built with me." />
        <div className="testimonial-stage reveal">
          <div className="quote-mark">“</div>
          <blockquote>{testimonials[activeTestimonial].quote}</blockquote>
          <div className="quote-person"><strong>{testimonials[activeTestimonial].name}</strong><span>{testimonials[activeTestimonial].relation}</span><small>{testimonials[activeTestimonial].detail}</small></div>
          <div className="testimonial-dots">{testimonials.map((_, i) => <button aria-label={`Show recommendation ${i+1}`} className={i === activeTestimonial ? "active" : ""} onClick={() => setActiveTestimonial(i)} key={i} />)}</div>
        </div>
      </section>

      <section className="section meet-section">
        <SectionTitle index={9} kicker="MEET PRAJWAL" title="You’ve seen the work. Meet the person." />
        <div className="meet-card reveal">
          <div className="avatar-stage"><div className="avatar-halo" /><div className="avatar-silhouette"><div className="avatar-head"/><div className="avatar-body"/></div><div className="audio-bars">{Array.from({length:18}).map((_,i)=><i key={i}/>)}</div></div>
          <div className="meet-copy"><span className="eyebrow">60-SECOND INTRO</span><h3>A short hello, in my own words.</h3><p>Until a real intro video is added, this section can narrate the introduction using your browser’s voice system. Replace it later with your own 45–60 second video without changing the layout.</p><button className="primary-btn" onClick={speakIntro}>▶ Play narrated intro</button></div>
        </div>
      </section>

      <section id="skills" className="section skills-section">
        <SectionTitle index={10} kicker="TOOLKIT" title="Things I know enough to build with." text="Not a keyword wall. Pick a world and explore the tools inside it." />
        <div className="skill-universe reveal">
          <div className="skill-nav">{Object.keys(skillGroups).map(k => <button key={k} className={skillGroup === k ? "active" : ""} onClick={() => setSkillGroup(k)}>{k}</button>)}</div>
          <div className="skill-cloud">{skillGroups[skillGroup].map((s,i)=><span style={{"--i":i}} key={s}>{s}</span>)}</div>
        </div>
      </section>

      <section id="education" className="section education-section">
        <SectionTitle index={11} kicker="EDUCATION" title="The formal part of the learning." />
        <div className="edu-grid">
          <article className="edu-card reveal"><span>2024 — 2026</span><h3>Kent State University</h3><h4>M.S. Computer Science</h4><strong>GPA {profile.gpa}</strong><p>Advanced databases, AI/ML, deep learning, data mining, security & privacy, social/graph networks, graphics and systems-oriented study.</p></article>
          <article className="edu-card reveal"><span>2019 — 2023</span><h3>JSS Academy of Technical Education</h3><h4>B.E. Computer Science</h4><p>Computer science foundations spanning algorithms, DBMS, operating systems, networking, web development, software engineering, graphics, cloud and mobile application development.</p></article>
        </div>
      </section>

      <section className="section milestones-section">
        <SectionTitle index={12} kicker="MILESTONES" title="Moments that stayed with me." />
        <div className="milestone-grid">{milestones.map(([a,b],i)=><article className="milestone reveal" key={i}><span>{String(i+1).padStart(2,"0")}</span><h3>{a}</h3><p>{b}</p></article>)}</div>
      </section>

      <section id="contact" className="section contact-section">
        <div className="end-label reveal">YOU REACHED THE END.</div>
        <h2 className="reveal">But I haven’t.</h2>
        <p className="reveal">There are still systems I haven’t built, questions I haven’t asked, places I haven’t worked, people I haven’t met and ideas that haven’t occurred to me yet.</p>
        <a className="end-link reveal" href={`mailto:${profile.email}`}>THE STORY CONTINUES →</a>
        <div className="social-cards reveal">{profile.socials.map(s=><a href={s.url} target="_blank" rel="noreferrer" key={s.label}><small>{s.note}</small><strong>{s.label}</strong><span>{s.value}</span><i>↗</i></a>)}</div>
      </section>
    </main>

    <footer><div><strong>PRAJWAL DEVARAJ</strong><span>Built from curiosity. Powered by too many ideas.</span></div><div>© 2026 · Digital universe v2.0</div></footer>

    <AICompanion onNavigate={navigate} />

    {storyOpen && <div className="story-overlay">
      <button className="story-close" onClick={()=>setStoryOpen(false)}>×</button>
      <div className="story-counter">{String(storyStep+1).padStart(2,"0")} / {String(story.length).padStart(2,"0")}</div>
      <div className="story-scene"><span>P · STORY MODE</span><h2>{story[storyStep][0]}</h2><p>{story[storyStep][1]}</p></div>
      <div className="story-controls"><button disabled={storyStep===0} onClick={()=>setStoryStep(s=>s-1)}>← Previous</button><button onClick={()=> storyStep===story.length-1 ? setStoryOpen(false) : setStoryStep(s=>s+1)}>{storyStep===story.length-1 ? "Return to universe" : "Next chapter →"}</button></div>
    </div>}
  </div>;
}
