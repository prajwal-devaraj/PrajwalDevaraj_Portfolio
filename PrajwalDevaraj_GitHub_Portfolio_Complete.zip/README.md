# Prajwal Devaraj — Digital Universe

A cinematic, single-theme personal portfolio built with React + Vite. It is designed as a complete profile — not just a job résumé — covering engineering, AI/ML research, projects, teaching, leadership, service work, sponsorship experience, recommendations, education, interests and personal story.

## Highlights

- Cinematic dark visual system
- Animated AI companion **P** that enters the page and docks as a chatbot
- Story Mode guided narrative
- Full profile/contact passport
- Complete experience timeline
- Research lab with completed / active / planned states
- 40+ project archive with filters and search
- LinkedIn recommendation excerpts
- Browser-narrated intro placeholder for a future real video
- Skills universe
- Milestones and social profile universe
- No light/dark switch — one consistent brand theme
- Responsive + reduced-motion support
- GitHub Actions deployment to GitHub Pages

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Deploy to GitHub Pages

This repository includes `.github/workflows/deploy.yml`.

1. Push the project to the `main` branch of `PrajwalDevaraj_Portfolio`.
2. On GitHub open **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions**.
4. Push a commit. The included workflow will build and deploy the site.

The Vite base is already configured for:

`/PrajwalDevaraj_Portfolio/`

## Main content editing

Most biography/project data is in:

`src/data/content.js`

Main page composition:

`src/components/Portfolio.jsx`

AI guide:

`src/components/AICompanion.jsx`

Projects/search/filter experience:

`src/components/ProjectUniverse.jsx`

Visual system:

`src/styles/global.css`

## Real intro video later

The `Meet Prajwal` section currently uses the browser Web Speech API for a narrated placeholder. Replace the avatar stage with your own `<video>` when you record a 45–60 second introduction.

## Important content notes

- GPA: **3.97 / 4.00**
- Languages: **English, Kannada, Telugu, Hindi**
- Upcoming research is visually labeled as planned and is not presented as completed work.
- The founder-style section describes a builder/ownership mindset; it does not claim a CEO/founder title.
